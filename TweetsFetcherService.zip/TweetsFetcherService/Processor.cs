﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TweetSharp;

namespace TweetsFetcherService
{
    public class Processor
    {
        public string _consumerKey;

        public string _consumerSecret;

        public string _accessToken;

        public string _tokenSecret;

        public Processor()
        {
            this._consumerKey = "TTLNnSsaDGT3aWjw0i3Cg7WKM";
            this._consumerSecret = "Zoi8i3wj5TFGvo2o1RD0XtfCZYrLhWGnKLjfrO9EKHLAhBZ8QN";
            this._accessToken = "761654880301875200-m3iMVA1QumOssd8xbaMq39LVuKhJkGH";
            this._tokenSecret= "TIUwadscaqL91CQu53k42AJtwleHlgNp5wuGd2wL1xZSt";
        }

        public void GetTweets()
        {
            TwitterClientInfo twitterClientInfo = new TwitterClientInfo();
            twitterClientInfo.ConsumerKey = this._consumerKey; //Read ConsumerKey out of the app.config
            twitterClientInfo.ConsumerSecret = this._consumerSecret; //Read the ConsumerSecret out the app.config
            TwitterService service = new TwitterService(twitterClientInfo);
            //service.TraceEnabled = true;
            service.AuthenticateWith(this._accessToken, this._tokenSecret);

            const int maxStreamEvents = 10;

            var block = new AutoResetEvent(false);
            var count = 0;


            service.StreamUser((streamEvent, response) =>
            {
            });

          //  block.WaitOne();
            service.CancelStreaming();
        }

        public void Authenticate(string oauth_token, string oauth_verifier)
        {
            if (string.IsNullOrEmpty(oauth_verifier))
            {
                TwitterClientInfo twitterClientInfo = new TwitterClientInfo();
                twitterClientInfo.ConsumerKey = this._consumerKey; //Read ConsumerKey out of the app.config
                twitterClientInfo.ConsumerSecret = this._consumerSecret; //Read the ConsumerSecret out the app.config

                TwitterService twitterService = new TwitterService(twitterClientInfo);


                //Now we need the Token and TokenSecret

                //Firstly we need the RequestToken and the AuthorisationUrl
                OAuthRequestToken requestToken = twitterService.GetRequestToken();

                string authUrl = twitterService.GetAuthorizationUri(requestToken).ToString();

                //authUrl is just a URL we can open IE and paste it in if we want
                Process.Start(authUrl); //Launches a bro
            }
            else
            {
                var requestToken = new OAuthRequestToken { Token = oauth_token };

                TwitterService service = new TwitterService(this._consumerKey, this._consumerSecret);
                OAuthAccessToken accessToken = service.GetAccessToken(requestToken, oauth_verifier);

                service.AuthenticateWith(accessToken.Token, accessToken.TokenSecret);
                TwitterUser user = service.VerifyCredentials(new VerifyCredentialsOptions() { IncludeEntities = true });

                // return RedirectToAction("Index", "Home");
            }
        }

        public void Confirm(string pin)
        {
            //TwitterService service = new TwitterService(this._consumerKey, this._consumerSecret);
            //OAuthAccessToken accessToken = service.GetAccessToken(requestToken, pin);

            //string token = accessToken.Token; //Attach the Debugger and put a break point here
            //string tokenSecret = accessToken.TokenSecret; //And another Breakpoint here


            //twitterService.AuthenticateWith(AccessToken, AccessTokenSecret);
        }
    }
}
