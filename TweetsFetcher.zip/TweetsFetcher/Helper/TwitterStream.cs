﻿using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using Tweetinvi;
using Tweetinvi.Models;
using Tweetinvi.Streaming;
using TweetsFetcher.Models;

namespace TweetsFetcher.Helper
{
    public static class TwitterStream
    {
        private static ISampleStream _stream;
        private static readonly IHubContext _context = GlobalHost.ConnectionManager.GetHubContext<TwitterHub>();
        public static Dictionary<string, int> Emojis = new Dictionary<string, int>();
        public static async Task StartStream(CancellationToken token)
        {
            var newCreds = new TwitterCredentials()
            {
                ConsumerKey = "TTLNnSsaDGT3aWjw0i3Cg7WKM",
                ConsumerSecret = "Zoi8i3wj5TFGvo2o1RD0XtfCZYrLhWGnKLjfrO9EKHLAhBZ8QN",
                AccessToken = "761654880301875200-m3iMVA1QumOssd8xbaMq39LVuKhJkGH",
                AccessTokenSecret = "TIUwadscaqL91CQu53k42AJtwleHlgNp5wuGd2wL1xZSt"
            };
            Auth.SetCredentials(newCreds);
            var emojis = GetEmojisFromJson();
            Emojis = emojis.ToDictionary(x => x, x => 0);
            _stream = Stream.CreateSampleStream(newCreds);
            _stream.AddTweetLanguageFilter(Language.English);
            _stream.TweetReceived += async (sender, args) =>
            {
                if (token.IsCancellationRequested)
                {

                    _stream.StopStream();
                    var trends = Trends.GetTrendsAt(1);
                    var trendingEmojis = Emojis.Where(c => c.Value > 0);
                    await _context.Clients.All.UpdateTrendingTopics(trends);
                    await _context.Clients.All.UpdateTrendingEmojis(trendingEmojis);
                }
                var text = args.Tweet.Text;
                GetEmojis(text);
                await _context.Clients.All.updateTweet(new TweetModel()
                {
                    Text = text.IndexOf("http") > 0 ? text.Substring(0, text.IndexOf("http")) : text,
                    ContentUrl = args.Tweet.Urls.Count > 0 ? args.Tweet.Urls.FirstOrDefault().ExpandedURL : string.Empty,
                    TweetUrl = args.Tweet.Url,
                    CreatedTime = args.Tweet.TweetLocalCreationDate,
                    HasMedia = args.Tweet.Media.Count > 0 ? true : false,
                    HasUrls = args.Tweet.Urls.Count > 0 ? true : false,
                    TrendingDomains = args.Tweet.Urls.Select(c => new Uri(c.ExpandedURL).Host).ToList()
                });

            };

            _stream.StreamPaused += async (sender, args) =>
            {
                await _context.Clients.All.updateStatus("Paused.");
            };
            _stream.StreamResumed += async (sender, args) =>
            {
                await _context.Clients.All.updateStatus("Streaming...");
            };
            _stream.StreamStarted += async (sender, args) =>
            {
                await _context.Clients.All.updateStatus("Started syncing tweets.");
            };
            _stream.StreamStopped += async (sender, args) =>
            {
                await _context.Clients.All.updateStatus("Stopped syncing");
            };
            await _stream.StartStreamAsync();

        }

        public static void GetEmojis(string text)
        {
            try
            {

                string decimalEncoded = HttpUtility.HtmlEncode(text);
                var emojis = decimalEncoded.Split('&').Where(c => c.StartsWith("#") && c.EndsWith(";"));
                foreach (var emoji in emojis)
                {
                    int decimalvalue = int.Parse(emoji.Replace("#", string.Empty).Replace(";", string.Empty));
                    string hexEncoded = string.Format("{0:X}", decimalvalue);
                    if (Emojis.ContainsKey(hexEncoded))
                    {
                        var value = Emojis[hexEncoded];
                        Emojis[hexEncoded] = value + 1;
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {

            }
        }

        public static List<string> GetEmojisFromJson()
        {
            // read JSON directly from a file
            string path = System.Web.Hosting.HostingEnvironment.MapPath(@"\Content\emoji.json");
            using (System.IO.StreamReader file = System.IO.File.OpenText(path))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                JArray o2 = (JArray)JToken.ReadFrom(reader);
                var emojiValues = (from p in o2.Root
                                   select (string)p["unified"]).ToList();
                return emojiValues;
            }
        }
    }
}