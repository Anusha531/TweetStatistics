﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TweetsFetcher.Models
{
    public class TweetList
    {
        public List<TweetModel> Tweets { get; set; }

        public int TotalTweets { get; set; }

        public int AvgTweetsPH { get; set; }

        public int AvgTweetsPM { get; set; }

        public int AvgTweetsPS { get; set; }

        public double TweetWithMediaPercent { get; set; }

        public double TweetWithUrlsPercent { get; set; }

        public List<Topics> TopHashTags { get; set; }

        public TweetList()
        {
            this.Tweets = new List<TweetModel>();
            this.TopHashTags = new List<Topics>();
        }

    }
}