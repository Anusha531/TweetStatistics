﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TweetsFetcher.Models
{
    public class Topics
    {
        public string Name { get; set; }

        public string Url { get; set; }
    }
}