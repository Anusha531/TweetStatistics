﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TweetsFetcher.Models
{
    public class TweetModel
    {
        public string Text { get; set; }

        public string TweetUrl { get; set; }

        public string ContentUrl { get; set; }

        public DateTime CreatedTime { get; set; }

        public bool HasMedia { get; set; }

        public bool HasUrls { get; set; }

        public List<string> Emojis { get; set; }

        public List<string> TrendingDomains { get; set; }
    }
}